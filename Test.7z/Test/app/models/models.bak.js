{
  "$schema": "http://json-schema.org/draft-04/schema#",
  "id": "http://jsonschema.net",
  "type": "object",
  "properties": {
    "address": {
      "id": "http://jsonschema.net/address",
      "type": "object",
      "properties": {
        "building": {
          "id": "http://jsonschema.net/address/building",
          "type": "string"
        },
        "coord": {
          "id": "http://jsonschema.net/address/coord",
          "type": "array",
          "items": [
            {
              "id": "http://jsonschema.net/address/coord/0",
              "type": "number"
            },
            {
              "id": "http://jsonschema.net/address/coord/1",
              "type": "number"
            }
          ]
        },
        "street": {
          "id": "http://jsonschema.net/address/street",
          "type": "string"
        },
        "zipcode": {
          "id": "http://jsonschema.net/address/zipcode",
          "type": "string"
        }
      }
    },
    "borough": {
      "id": "http://jsonschema.net/borough",
      "type": "string"
    },
    "cuisine": {
      "id": "http://jsonschema.net/cuisine",
      "type": "string"
    },
    "grades": {
      "id": "http://jsonschema.net/grades",
      "type": "array",
      "items": [
        {
          "id": "http://jsonschema.net/grades/0",
          "type": "object",
          "properties": {
            "date": {
              "id": "http://jsonschema.net/grades/0/date",
              "type": "object",
              "properties": {}
            },
            "grade": {
              "id": "http://jsonschema.net/grades/0/grade",
              "type": "string"
            },
            "score": {
              "id": "http://jsonschema.net/grades/0/score",
              "type": "integer"
            }
          }
        },
        {
          "id": "http://jsonschema.net/grades/1",
          "type": "object",
          "properties": {
            "date": {
              "id": "http://jsonschema.net/grades/1/date",
              "type": "object",
              "properties": {}
            },
            "grade": {
              "id": "http://jsonschema.net/grades/1/grade",
              "type": "string"
            },
            "score": {
              "id": "http://jsonschema.net/grades/1/score",
              "type": "integer"
            }
          }
        },
        {
          "id": "http://jsonschema.net/grades/2",
          "type": "object",
          "properties": {
            "date": {
              "id": "http://jsonschema.net/grades/2/date",
              "type": "object",
              "properties": {}
            },
            "grade": {
              "id": "http://jsonschema.net/grades/2/grade",
              "type": "string"
            },
            "score": {
              "id": "http://jsonschema.net/grades/2/score",
              "type": "integer"
            }
          }
        },
        {
          "id": "http://jsonschema.net/grades/3",
          "type": "object",
          "properties": {
            "date": {
              "id": "http://jsonschema.net/grades/3/date",
              "type": "object",
              "properties": {}
            },
            "grade": {
              "id": "http://jsonschema.net/grades/3/grade",
              "type": "string"
            },
            "score": {
              "id": "http://jsonschema.net/grades/3/score",
              "type": "integer"
            }
          }
        },
        {
          "id": "http://jsonschema.net/grades/4",
          "type": "object",
          "properties": {
            "date": {
              "id": "http://jsonschema.net/grades/4/date",
              "type": "object",
              "properties": {}
            },
            "grade": {
              "id": "http://jsonschema.net/grades/4/grade",
              "type": "string"
            },
            "score": {
              "id": "http://jsonschema.net/grades/4/score",
              "type": "integer"
            }
          }
        }
      ]
    },
    "name": {
      "id": "http://jsonschema.net/name",
      "type": "string"
    },
    "restaurant_id": {
      "id": "http://jsonschema.net/restaurant_id",
      "type": "string"
    }
  }
}
