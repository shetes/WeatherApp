var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var restSchema = new Schema({
    address: {
      building: String,
      coord: [],
      street: String,
      zipcode: String
    },
    borough: String,
    cuisine: String,
    grades: [{
            date: Date,
            grade: String,
            score: Number
          }],
    name: String,
    restaurant_id: String
  });

mongoose.model('Restaurant', restSchema);
