var ticker = ["MSFT", "46.00", "AAPL", "116.00", "GOOG", "511.00"];
var portfolio = ["MSFT", "GOOG"];
var pList = {};

for (var i = 0; i < ticker.length; i = i + 2) {
  var flag = "N";
  if (portfolio.indexOf(ticker[i]) != -1) {
    flag = "Y";
  }
  console.log(ticker[i] + "," + ticker[i + 1] + "," + flag);
}
