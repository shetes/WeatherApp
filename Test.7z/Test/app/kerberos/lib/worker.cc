#include "worker.h"

Worker::Worker() {
}

Worker::~Worker() {  
}