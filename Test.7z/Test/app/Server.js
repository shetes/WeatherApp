// //Lets require/import the HTTP module
// var http = require('http');
//
// //Lets define a port we want to listen to
// const PORT=7777;
//
// //We need a function which handles requests and send response
// function handleRequest(request, response){
//     response.end('It Works!! Path Hit: ' + request.url);
// }
//
// //Create a server
// var server = http.createServer(handleRequest);
//
// //Lets start our server
// server.listen(PORT, function(){
//     //Callback triggered when server is successfully listening. Hurray!
//     //console.log("Server listening on: http://localhost:%s", PORT);
// });

var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
console.log('Test');

require('./models/models');
var api = require('./routes/api');
var mongoose = require('mongoose');                         //add for Mongo support
mongoose.connect('mongodb://localhost/test');              //connect to Mongo
var app = express();

app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', api);

// app.use(
//     "/", //the URL throught which you want to access to you static content
//     express.static(__dirname) //where your static content is located in your filesystem
// );
app.listen(3000); //the port you want to use
