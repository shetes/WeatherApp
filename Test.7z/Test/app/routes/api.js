var express = require('express');
var router = express.Router();
var mongoose = require( 'mongoose' );
var Restaurant = mongoose.model('Restaurant');

var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://localhost/test';

var findRestaurants = function(db, callback) {
  //  var cursor =db.collection('restaurants').find({"borough": "Bronx"} );
  //  cursor.each(function(err, doc) {
  //     assert.equal(err, null);
  //     if (doc != null) {
  //        console.dir(doc);
  //     } else {
  //        callback();
  //     }
  //  });
  return db.collection('restaurants').find({"borough": "Bronx"} );
};

//  router.route('/restaurants')
//	//gets all posts
//	.get(function(req, res){
//	  console.log('All');
//	  MongoClient.connect(url, function(err, db) {
//		assert.equal(null, err);
//		var coll = db.collection('restaurants');
//		coll.find().toArray(function(err, items) {
//		  console.log(items.length);
//		  return res.status(200).send(items);
//		});
//	  });
//	});

   router.route('/restaurant/:id')
	  //gets specified post
	  .get(function(req, res){
		console.log('Restaurant: ' + req.params.id);
		MongoClient.connect(url, function(err, db) {
		  assert.equal(null, err);
		  var coll = db.collection('restaurants');
		  coll.find({ "restaurant_id": req.params.id }).toArray(function(err, items) {
			console.log(items.length);
            if (items.length > 0) {
              return res.status(200).send(items[0]);
            } else {
			  return [];
			}
		  });
		});
	  });

   router.route('/restaurants/:borough')
	  //gets specified post
	  .get(function(req, res){
		console.log('By borough');
		MongoClient.connect(url, function(err, db) {
		  assert.equal(null, err);
		  var coll = db.collection('restaurants');
		  if (req.params.borough === "All") {
			coll.find().toArray(function(err, items) {
			  console.log(items.length);
			  return res.status(200).send(items);
			});
          } else {
			console.log(req.params.borough);
			coll.find({"borough": req.params.borough}).toArray(function(err, items) {
			  console.log(items.length);
			  return res.status(200).send(items);
			});
		  }
		});
	  });

   router.route('/boroughs')
	  //gets specified post
	  .get(function(req, res){
		console.log('Boroughs');
		MongoClient.connect(url, function(err, db) {
		  assert.equal(null, err);
		  var docs = [];
		  var coll = db.collection('restaurants');
		//   var myarray = [];
		  coll.distinct("borough", (function(err, docs) {
			//console.log(docs);
			//docs.forEach(function(value, index) {
			//  var item = {
			//	"borough": value
			//  }
			//  //console.log(item);
			//  myarray.push(item);
			//});
			////return myarray;
			//return res.status(200).send(JSON.stringify(myarray));
            return res.status(200).send(docs);
		  }));
		});
	  });

   router.route('/cuisines')
	  //gets specified post
	  .get(function(req, res){
		console.log('Cuisines');
		MongoClient.connect(url, function(err, db) {
		  assert.equal(null, err);
		  var docs = {};
		  var coll = db.collection('restaurants');
		  var items = coll.distinct("cuisine", (function(err, docs) {
			return res.status(200).send(docs);
		  }));
		});
	  });

// Restaurant.find(function(err, restaurants){
		// 	console.log('debug2');
		// 	if(err){
		// 		return res.send(500, err);
		// 	}
    //   return res.send(200,restaurants);
		// });

module.exports = router;
