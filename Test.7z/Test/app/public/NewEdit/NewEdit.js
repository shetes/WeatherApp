'use strict';

angular.module('myApp.NewEdit', ['ngRoute', 'ngResource', 'ngCookies'])

.config(['$routeProvider', function($routeProvider, $route, restaurantSvc) {
  $routeProvider.when('/NewEdit/:id', {
    templateUrl: 'NewEdit/NewEdit.html',
    controller: 'NewEditCtrl',
    resolve: {
      restaurant: function(restaurantSvc, $route, $q) {
        console.log("Borough: " + $route.current.params.borough);
        if ($route.current.params.id) {
          var deferred = $q.defer();
          restaurantSvc.get({'id': $route.current.params.id},
             function(successData) {
                  deferred.resolve(successData); 
          }, function(errorData) {
                  deferred.reject(); // you could optionally pass error data here
          });
          return deferred.promise;
        } else {
           return {};
        }
      },
      boroughs: function(boroughSvc, $q) {
        var deferred = $q.defer();
        boroughSvc.query(function(successData) {
                deferred.resolve(successData); 
        }, function(errorData) {
                deferred.reject(); // you could optionally pass error data here
        });
        return deferred.promise;
      },
      cuisines: function(cuisineSvc, $q) {
        var deferred = $q.defer();
        cuisineSvc.query(function(successData) {
                deferred.resolve(successData); 
        }, function(errorData) {
                deferred.reject(); // you could optionally pass error data here
        });
        return deferred.promise;
      }
    }
  });
}])

.controller('NewEditCtrl', function($scope, $location, $routeParams, $cookies, 
                                    restaurant, boroughs, cuisines) {
  $scope.restaurant = restaurant;
  $scope.boroughs = boroughs.sort();
  $scope.cuisines = cuisines.sort();
});
