'use strict';

angular.module('myApp.List', ['ngRoute', 'ngResource', 'ngCookies'])

.config(['$routeProvider', function($routeProvider, $route) {
  $routeProvider.when('/List/:borough', {
    templateUrl: 'List/List.html',
    controller: 'ListCtrl',
    resolve: {
      restaurants: function(restaurantsSvc, $route, $q) {
        console.log("Borough: " + $route.current.params.borough);
        if ($route.current.params.borough) {
          var deferred = $q.defer();
          restaurantsSvc.query({'borough': $route.current.params.borough},
             function(successData) {
                  deferred.resolve(successData); 
          }, function(errorData) {
                  deferred.reject(); // you could optionally pass error data here
          });
          return deferred.promise;
        } else {
           return {};
        }
      },
      boroughs: function(boroughSvc, $q) {
        var deferred = $q.defer();
        boroughSvc.query(function(successData) {
                deferred.resolve(successData); 
        }, function(errorData) {
                deferred.reject(); // you could optionally pass error data here
        });
        return deferred.promise;
      },
      cuisines: function(cuisineSvc, $q) {
        var deferred = $q.defer();
        cuisineSvc.query(function(successData) {
                deferred.resolve(successData); 
        }, function(errorData) {
                deferred.reject(); // you could optionally pass error data here
        });
        return deferred.promise;
      }
    }
  });
}])

.filter('byCuisine', function() {
  return function(restaurants, scope) {
    if (!scope.selectedCuisine || scope.selectedCuisine === 'All'
                || scope.selectedCuisine === 'null') {
      return restaurants;
    } else {
      var out = [];
      //console.log(restaurants.length + ", " + scope.selectedCuisine);
      angular.forEach(restaurants, function(restaurant) {
        //console.log(restaurant.cuisine);
        if (restaurant.cuisine === scope.selectedCuisine) {
          out.push(restaurant);
        }
      });
      return out;
    }
  };
})

.controller('ListCtrl', function($scope, $location, $routeParams, $cookies, 
                                    restaurants, boroughs, cuisines) {
  $scope.restaurants = restaurants;
  $scope.boroughs = boroughs;
  $scope.selectedBorough = $scope.boroughs.filter(function(val, index) {
    return val === $routeParams.borough;
  })[0];
  
  $scope.cuisines = cuisines.sort();
  var selectedCuisine = $cookies.get('selectedCuisine');
  $scope.selectedCuisine = selectedCuisine;

  $scope.restaurantsByBorough = function() {
    console.log("Selected Borough: " + $scope.selectedBorough);
    if ($scope.selectedBorough) {
      $location.path("/List/" + $scope.selectedBorough);
    } else {
      $location.path("/List/All");
    }
    
    //$scope.restaurants = restaurantSvc.query({'borough': $scope.selectedBorough});
  }
  
  $scope.restaurantsByCuisine = function() {
    $cookies.put('selectedCuisine', $scope.selectedCuisine);
  }
});
