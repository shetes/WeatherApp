'use strict';

// Declare app level module which depends on views, and components
var app = angular.module('myApp', [
  'ngRoute',
  'ngResource',
  'myApp.List',
  'myApp.NewEdit'
])

.factory('restaurantSvc', function($resource) {
  return $resource('/api/restaurant/:id?', {id: '@id'});
})
.factory('restaurantsSvc', function($resource) {
  return $resource('/api/restaurants/:borough', {borough: '@borough'});
})
.factory('boroughSvc', function($resource) {
  return $resource('/api/boroughs');
})
.factory('cuisineSvc', function($resource) {
  return $resource('/api/cuisines');
})

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.otherwise({redirectTo: '/List/:borough'});
}]);
